# django-hlsfield

Django fields for video uploads:

- `VideoField`: extracts duration & width/height (ffprobe), saves a preview frame (ffmpeg).
- `HLSVideoField`: inherits VideoField and builds HLS (variants + master.m3u8).
- Celery **optional** (background) or **sync** fallback.
- JSON sidecar fallback for metadata/preview if you don't add model fields.

## 0.1.1
- Safe import without configured Django settings.
- Avoid DoesNotExist on add: HLS build is deferred to `post_save` when object gets PK.

## Install
```bash
pip install django-hlsfield
# optional extras
pip install "django-hlsfield[celery]"  # background tasks
```
