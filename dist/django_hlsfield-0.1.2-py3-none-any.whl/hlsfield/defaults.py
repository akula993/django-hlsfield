# Safe defaults: don't require configured Django settings on import
try:
    from django.conf import settings as _settings
    _CONFIGURED = getattr(_settings, "configured", False)
except Exception:  # Django not installed or misconfigured
    _settings = None
    _CONFIGURED = False

def _get(name, default):
    if _CONFIGURED and _settings is not None:
        try:
            return getattr(_settings, name, default)
        except Exception:
            return default
    return default

FFPROBE = _get("HLSFIELD_FFPROBE", "ffprobe")
FFMPEG  = _get("HLSFIELD_FFMPEG", "ffmpeg")

DEFAULT_LADDER = _get("HLSFIELD_DEFAULT_LADDER", [
    {"height": 240,  "v_bitrate": 300,  "a_bitrate": 64},
    {"height": 360,  "v_bitrate": 800,  "a_bitrate": 96},
    {"height": 480,  "v_bitrate": 1200, "a_bitrate": 96},
    {"height": 720,  "v_bitrate": 2500, "a_bitrate": 128},
    {"height": 1080, "v_bitrate": 4500, "a_bitrate": 160},
])
SEGMENT_DURATION = int(_get("HLSFIELD_SEGMENT_DURATION", 6))
